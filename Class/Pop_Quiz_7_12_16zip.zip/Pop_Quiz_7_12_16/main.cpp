/* 
 * File:   main.cpp
 * Author: Raul Gonzalez
 * Created on July 8, 2016, 12:27 PM
 * Purpose:  Template
 */

//System Libraries
#include <iostream>  //Input/Output Library
using namespace std; //Namespace of the System Libraries

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
   int n=0;
   
    //Input Data
   cout<<"Enter the number to count"<<endl;
   cin>>n;
   
   n+=n;
 
   
   
   
    //Process the Data
    
    
    //Output the data
   cout<<n;
    
    //Exit Stage Right!
    return 0;
}