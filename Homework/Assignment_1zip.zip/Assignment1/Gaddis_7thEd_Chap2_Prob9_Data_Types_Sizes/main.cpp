/* 
 * File:   main.cpp
 * Author: Raul Gonzalez
 *
 * Created on June 21, 2016, 1:33 PM
 * Purpose: First Process
 */
//System Libraries
#include <iostream>//Input /Output Stream Library
using namespace std;// Iostream uses the standard namespace

//User Libraries

// Global Constants

//Function Prototypes

//Execution Begins Here!
/*
 * 
 */
int main(int argc, char** argv) {
//Declare variables here, no doubles
    char a;
    int b;
    float c;
    double d;
    
    
// Input Data
  

// Process Data
    
// Output Data
cout<<"A Character has "<<sizeof(a)<<" bytes"<<endl;
cout<<"An Integer has  "<<sizeof(b)<<" bytes"<<endl;
cout<<"A Float has     "<<sizeof(c)<<" bytes"<<endl;
cout<<"A Double has    "<<sizeof(d)<<" bytes"<<endl;


//Exit stage Right!
    
    return 0;
}

