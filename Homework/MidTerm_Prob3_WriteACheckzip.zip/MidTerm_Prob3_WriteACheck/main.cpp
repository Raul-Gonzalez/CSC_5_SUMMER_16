/* 
 * File:   main.cpp
 * Author: Raul Gonzalez
 * Created on July 12, 2016, 12:27 PM
 * Purpose: Write A Check
 */

//System Libraries
#include <iostream>  //Input/Output Library
#include <string>    //Library to call strings
using namespace std; //Namespace of the System Libraries

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    unsigned int amnt=0;     // Date and amount will be entered in numeric form
    unsigned int nThsands=0,nHundres=0,nTens=0,nOnes=0;  //Strip off the digits
    string date;
    string payee;
    string acntHold;
    
   
    //Input Data
    cout<<"This program will print out a check"<<endl;
    cout<<"Input the date"<<endl;
    cin>>date;
    
    cout<<"Input the Payee:";
    getline(cin, payee);
    cout<<endl;
    cout<<"Input the Account Holder:";
    cout<<endl;
    getline(cin, acntHold);
    
    cout<<"Input the amount in dollars"<<endl;
    cin>>amnt;
    
    
    //Output the data
    cout<<"__________Check Output____________"<<endl;
    cout<<acntHold<<endl;
    cout<<"STREET ADDRESS"<<endl;
    cout<<"CITY, STATE  ZIP                            Date:  "<<date<<endl;
    cout<<endl;
    cout<<"Pay to the Order of:  "<<payee<<"              $ "<<amnt<<endl;
    
    //Process the Data
    //Thousands Position
    if (amnt<1 || amnt > 1999)return 1;
    
    nThsands=(amnt-amnt%1000)/1000;//Number of Thousands
    switch (nThsands){
        case 1:cout<<"One Thousand ";break;
        
        
    }
    //Hundreds Position
    amnt-=nThsands*1000;
    nHundres=(amnt-amnt%100)/100;  //Number of Hundreds
    switch(nHundres){
        case 9:cout<<"Nine Hundred ";break;
        case 8:cout<<"Eight Hundred ";break;
        case 7:cout<<"Seven HUndred ";break;
        case 6:cout<<"Six Hundred ";break;
        case 5:cout<<"Five Hundred ";break;
        case 4:cout<<"Four Hundred ";break;
        case 3:cout<<"Three Hundred ";break;
        case 2:cout<<"Two Hundred ";break;
        case 1:cout<<"One Hundred ";break;
        
    }
    //Tens Position
    amnt-=nHundres*100;
    nTens=(amnt-amnt%10)/10;       //Number of Tens
    switch(nTens){
        case 9:cout<<"Ninety ";break;
        case 8:cout<<"Eighty ";break;
        case 7:cout<<"Seventy ";break;
        case 6:cout<<"Sixty ";break;
        case 5:cout<<"Fifty ";break;
        case 4:cout<<"Forty ";break;
        case 3:cout<<"Thirty ";break;
        case 2:cout<<"Twenty ";break;
        case 1:{
        //Ones Position
        amnt-=nTens*10;
        nOnes=(amnt-amnt%1)/1;            //Number of Ones
              switch(nOnes){
                case 0:cout<<"Ten ";break;
                case 1:cout<<"Eleven ";break;
                case 2:cout<<"Twelve ";break;
                case 3:cout<<"Thirteen ";break;
                case 4:cout<<"Fourteen ";break;
                case 5:cout<<"Fifteen ";break;
                case 6:cout<<"Sixteen ";break;
                case 7:cout<<"Seventeen ";break;
                case 8:cout<<"Eighteen ";break;
                case 9:cout<<"Nineteen ";break;
         
    }
  }
 }
    if(nTens!=1){
        switch(nOnes){
            case 0:if(nTens==0)cout<<"Zero ";break;
            case 1:cout<<"One ";break;
            case 2:cout<<"Two ";break;
            case 3:cout<<"Three ";break;
            case 4:cout<<"Four ";break;
            case 5:cout<<"Five ";break;
            case 6:cout<<"Six ";break;
            case 7:cout<<"Seven ";break;
            case 8:cout<<"Eight ";break;
            case 9:cout<<"Nine ";break;  
            cout<<amnt<<endl;
        }
    }
    cout<<amnt<<endl;
    cout<<endl;
    cout<<"BANK OF CSC5"<<endl;
    cout<<endl;
    cout<<"FOR:  GOTTA PAY THE RENT	            "<<acntHold<<endl;
    
    
    //Exit Stage Right!
    return 0;
}